"""Login Page Example"""
import cherrypy
import config
from time import time
import models.database_handler as db
from jinja2 import Environment, FileSystemLoader


class WebService:
    """This class should be inherited for different pages"""

    TEMPLATE_FOLDER = r"./views"

    def __init__(self, html_template_file_name):
        """Initialize variables"""
        self._environment = Environment(loader=FileSystemLoader(WebService.TEMPLATE_FOLDER))
        self._html_file = self._environment.get_template(html_template_file_name)


class VerifiedPage(WebService):
    """If user authorized returns welcome screen"""
    @cherrypy.expose
    def index(self):
        if cherrypy.session['authorized'] is True:
            return open('views/logined.html')
        else:
            return 'error.html'


class LoginWebService(WebService):
    """Serves as login web service which is responsible for user login etc..."""

    @cherrypy.expose
    def index(self):
        return self._html_file.render(Title='Login',
                                      Hint='Please enter credentials to login.')

    @cherrypy.tools.accept(media='text/plain')
    def GET(self):
        cherrypy.session['ts'] = time()
        cherrypy.log(cherrypy.session['ts'])

    @cherrypy.expose
    def POST(self, **kwargs):
        name = kwargs['name']
        pw = kwargs['pw']
        validate = db.SqLiteHandler().sql_query("user_credentials", name, "name,pw")
        if validate and name != validate[0][0]:
            return "INV_USER"
        else:
            if validate[0][1] == pw:
                cherrypy.session['authorized'] = True
                return "VERIFIED"
            else:
                return "WRONG PASSWORD"

    def PUT(self, another_string):
        cherrypy.session['authorized'] = another_string

    def DELETE(self):
        cherrypy.session.pop('authorized', None)


class RegisterWebService(WebService):
    """Page for register"""

    @cherrypy.expose
    def index(self):
        return open('register.html')


if __name__ == '__main__':
    cherrypy.config.update({'log.screen': True,
                            'log.access_file': '',
                            'log.error_file': 'error.txt'})
    webapp = LoginWebService('index.html')
    webapp.logined = VerifiedPage('logined.html')
    cherrypy.quickstart(webapp, '/', config.cherrpy_run_conf)
